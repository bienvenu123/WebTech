package com.example.bibafrica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibafricaApplicationTests {

    @Test
    void contextLoads() {
    }

}
